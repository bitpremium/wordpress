<?php
include('taxonomy-news_category.php');
