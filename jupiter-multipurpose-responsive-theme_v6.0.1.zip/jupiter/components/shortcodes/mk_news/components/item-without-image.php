<div class="news-meta-wrapper">
	<?php echo mk_get_shortcode_view('mk_news', 'components/categories', true); ?>
	<div class="clearboth"></div>
	<?php echo mk_get_shortcode_view('mk_news', 'components/title', true); ?>
	<?php echo mk_get_shortcode_view('mk_news', 'components/date', true); ?>
</div>

<?php echo mk_get_shortcode_view('mk_news', 'components/excerpt', true); ?>
<?php echo mk_get_shortcode_view('mk_news', 'components/read-more', true); ?>