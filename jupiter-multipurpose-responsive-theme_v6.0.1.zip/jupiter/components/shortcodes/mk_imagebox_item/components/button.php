<?php if(!empty( $view_params['btn_url'] )) { ?>
	<div class="item-button">
		<a href="<?php echo $view_params['btn_url']; ?>"><?php echo $view_params['btn_text']; ?></a>
	</div>
<?php } ?>